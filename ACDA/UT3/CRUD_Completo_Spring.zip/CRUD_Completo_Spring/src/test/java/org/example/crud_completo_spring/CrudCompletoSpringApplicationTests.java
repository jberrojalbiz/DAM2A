package org.example.crud_completo_spring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CrudCompletoSpringApplicationTests {

    @Test
    void contextLoads() {
    }

}

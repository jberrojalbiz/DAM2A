package es.masanz.acda.ut4.crud_completo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ClaseDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(ClaseDemoApplication.class, args);
	}

}

package es.masanz.acda.ut4.crud_completo.db.dao;

import es.masanz.acda.ut4.crud_completo.db.model.CanalYoutube;
import org.springframework.data.repository.CrudRepository;

public interface CanalYoutubeDAO extends CrudRepository<CanalYoutube, Integer> {
}
